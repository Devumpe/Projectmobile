package com.mycom.mobileproject;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    int day, month, year;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText input1 = (EditText) findViewById(R.id.edittotal);
        final EditText input2 = (EditText) findViewById(R.id.editspent);
        final EditText input3 = (EditText) findViewById(R.id.editbalance);
        final ImageButton submit = (ImageButton) findViewById(R.id.submit);
        final Button showdatebtn = (Button) findViewById(R.id.showdatebtn);
        final Button btnmonth = (Button) findViewById(R.id.monthbtn);
        final TextView txtDate = (TextView) findViewById(R.id.showdate);
        final TextView descrip = (TextView) findViewById(R.id.editdes);
        final TextView price = (TextView) findViewById(R.id.editprice);
        final TextView showtotal = (TextView) findViewById(R.id.showtotal);

        final String[] MONTHS = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};


        btnmonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);

                String total = input1.getText().toString();
                String spent = input2.getText().toString();
                String balance = input3.getText().toString();


                intent.putExtra("fromtotal", total);
                intent.putExtra("fromspent", spent);
                intent.putExtra("frombalance", balance);

                startActivity(intent);

            }


        });
        showdatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                Calendar cld = Calendar.getInstance();
                year = cld.get(Calendar.YEAR);
                month = cld.get(Calendar.MONTH);
                day = cld.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        txtDate.setText(dayOfMonth + " - " + MONTHS[(month + 1)] + " - " + year);
                    }
                }, year, month, day);

                datePickerDialog.show();
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String showdes = descrip.getText().toString();
                String showprice = price.getText().toString();
                if (showtotal.getText()!=" ") {
                    showtotal.setText(showtotal.getText() + "\n" + showdes + " " + showprice + "$");
                }


            }
        });

    }
}


