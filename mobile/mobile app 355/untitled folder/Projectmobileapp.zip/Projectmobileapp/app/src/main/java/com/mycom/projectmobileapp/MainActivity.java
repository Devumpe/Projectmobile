package com.mycom.projectmobileapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final AlertDialog.Builder dDialog = new AlertDialog.Builder(MainActivity.this);

        final EditText input1 = (EditText) findViewById(R.id.editname);
        final EditText input2 = (EditText) findViewById(R.id.editlastname);
        final EditText input3 = (EditText) findViewById(R.id.editbd);

        final Button btn = (Button) findViewById(R.id.submit);



        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                input1.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
                input2.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
                String name = input1.getText().toString();
                String lastname = input2.getText().toString();
                String birthday = input3.getText().toString();


                if(name.isEmpty()){
                    dDialog.setMessage("Please fill up this form.");
                    dDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    dDialog.show();
                }
                else{
                    String upperStringname = name.substring(0,1).toUpperCase() + name.substring(1);
                    String upperStringlastname = lastname.substring(0,1).toUpperCase() + lastname.substring(1);

                    intent.putExtra("fromname", upperStringname);
                    intent.putExtra("fromlast", upperStringlastname);
                    intent.putExtra("frombirth", birthday);

                    startActivity(intent);
                }

            }


        });

    }


}
