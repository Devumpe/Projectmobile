package com.mycom.projectmobileapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Calendar;

public class Main2Activity extends AppCompatActivity {

    public static int getAge(int year, int month, int day){
        Calendar birth = Calendar.getInstance();
        Calendar today = Calendar.getInstance();

        birth.set(year, month, day);

        int age = today.get(Calendar.YEAR) - birth.get(Calendar.YEAR);

        if (today.get(Calendar.DAY_OF_YEAR) < birth.get(Calendar.DAY_OF_YEAR)){
            age--;
        }

        Integer ageInt = new Integer(age);


        return ageInt;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        final TextView msgname = (TextView) findViewById(R.id.editname);
        String fromname = getIntent().getStringExtra("fromname");
        final TextView msglastname = (TextView) findViewById(R.id.editlastname);
        String fromlast = getIntent().getStringExtra("fromlast");
        final TextView msgbd = (TextView) findViewById(R.id.editbd);
        String frombirth = getIntent().getStringExtra("frombirth");
        String[] inputbd= frombirth.split("/");
        int result = getAge(Integer.valueOf(inputbd[2]),Integer.valueOf(inputbd[1]),Integer.valueOf(inputbd[0]));




        msgname.setText(fromname);
        msglastname.setText(fromlast);
        msgbd.setText(String.valueOf(result));



    }
}
